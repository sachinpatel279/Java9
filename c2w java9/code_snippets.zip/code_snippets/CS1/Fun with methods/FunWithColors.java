class FunColors{

	static String RED="\u001B[31m";
	static String RESET="\u001B[0m";
	static String GREEN="\u001B[32m";

	public static void main(String[]args){

		System.out.println(RED+ "I am red Core2webTechnologies"+RESET);
		System.out.println(GREEN+ "I am green Core2webTechnologies"+RESET);

	}

}
