class PrintStatements{

	public static void main(String[]args){

		System.out.println("Core 2 Web");

		System.out.println("Core 2 Web Again...");

		System.out.println("10"+20);

		System.out.println(10+20);

		System.out.printf("num1: %d\t num2 : %d\t addition : %d\n",10,20,10+20);

		System.out.println("John is "+20+"years old and born in "+1999);

	}

}
