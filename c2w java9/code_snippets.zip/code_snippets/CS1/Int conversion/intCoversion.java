class IntConversions{

	public static void main(String[]args){

		int num=15;

		System.out.println(Integer.toBinaryString(num));

		System.out.println(Integer.toHexString(num));

		System.out.println(Integer.toOctalString(num));

		System.out.println(Integer.toString(num));

		System.out.println(Integer.parseInt("1000"));

	}

}
