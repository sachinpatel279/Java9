class TokenDemo{

	public static void main(String[]args){

		String name="Sachin";
		int age=21;
		System.out.println("Name: "+name);
		System.out.println("Age: "+age);
	}

}
