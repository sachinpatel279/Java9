class IntDataType{

	public static void main(String[]args){

		int num=10;

		System.out.println("num:"+num);
		System.out.println("maximum int size:"+Integer.SIZE);
		System.out.println("maximum int size:"+Integer.MAX_VALUE);
		System.out.println("minimum int size:"+Integer.MIN_VALUE);

	}

}

