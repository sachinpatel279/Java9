class DoubleDataType{

	public static void main(String[]args){

		double num=10d;

		System.out.println("num:"+num);
		System.out.println("double size:"+Double.SIZE);
		System.out.println("maximum double size:"+Double.MAX_VALUE);
		System.out.println("minimum double size:"+Double.MIN_VALUE);
	}

}
