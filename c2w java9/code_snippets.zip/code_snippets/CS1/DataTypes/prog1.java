class ByteDataType{

	public static void main(String[]args){

		byte num=10;

		System.out.println("num:"+num);
		System.out.println("byte size:"+Byte.SIZE);
		System.out.println("maximum byte size:"+Byte.MAX_VALUE);
		System.out.println("minimum byte size:"+Byte.MIN_VALUE);
	}

}
