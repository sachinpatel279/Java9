class LongDataType{

	public static void main(String[]args){

		long num=101;

		System.out.println("num:"+num);
		System.out.println("long size:"+Long.SIZE);
		System.out.println("maximum long size:"+Long.MAX_VALUE);
		System.out.println("minimum long size:"+Long.MIN_VALUE);

	}

}
