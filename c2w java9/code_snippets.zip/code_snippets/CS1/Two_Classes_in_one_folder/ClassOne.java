public class ClassOne{

	public void displayInfoOne(){

		System.out.println("Hello everyone,");
		System.out.println("This method is from ClassOne,");

	}

}
