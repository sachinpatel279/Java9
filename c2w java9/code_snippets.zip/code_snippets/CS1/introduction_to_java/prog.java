class MyFirstProgram{

	public static void main(String[]args){

		System.out.println("Hello i am Sachin \n");
		System.out.println("From Pune  \n");
		System.out.println("Welcome To Core2Web Family!! \n");
	}

}
