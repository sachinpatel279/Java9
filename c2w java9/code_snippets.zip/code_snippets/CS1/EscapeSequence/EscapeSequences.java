class EscapeSeq{

	public static void main(String[]args){

		System.out.println("This is newline-> \n I am on new line now");

		System.out.println("This is backine-> \b");

		System.out.println("This is tab-> \t im after tab now");

		System.out.println("This is carriage return now see the 'T'at start of this string is missing->\r");

		System.out.println("This is formfeed-> \f i am here");

		System.out.println("This is single quote-> \'");

		System.out.println("This is newline-> \" ");

		System.out.println("This is newline-> \\ ");

	}

}
