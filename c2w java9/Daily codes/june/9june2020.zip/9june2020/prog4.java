

class FloatDemo{

	public static void main(String[]args){

		float f=25.6f;
		System.out.println(f);

		double d=25.6;
		System.out.println(d);

		if(f==d)
			System.out.println("same value");
		else
			System.out.println("Different value");


	}



}
