

class CharDemo{

	public static void main(String[] args){

		char ch='S';
		System.out.println(ch);

		char ch1=9;
		System.out.println(ch1);

		char ch2=65;
		System.out.println(ch2);
		
		char ch3=97;
		System.out.println(ch3);

		char ch4=49;
		System.out.println(ch4);
	}
}
