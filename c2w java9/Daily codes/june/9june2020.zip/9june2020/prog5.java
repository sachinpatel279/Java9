

class BooleanDemo{

	public static void main(String[]args){

		boolean x=true;
		System.out.println(x);

		boolean y=false;
		System.out.println(y);

	}
}
