

//Byte
//-128 to 127


class ByteDemo{

	public static void main(String[]args){

		byte myData=10;
		System.out.println(myData);

		byte myData2=127;
		System.out.println(myData2);
		myData2++;
		System.out.println(myData2);
		myData2++;
		System.out.println(myData2);




	}

}
