class SizeDemo{

	public static void main(String[]args){

		System.out.println(Byte.SIZE/8);	//1bytes
		System.out.println(Short.SIZE/8);	//2bytes
		System.out.println(Integer.SIZE/8);	//4bytes
		System.out.println(Long.SIZE/8);	//8bytes
		System.out.println(Float.SIZE/8);	//4bytes
		System.out.println(Double.SIZE/8);	//8bytes
		System.out.println(Character.SIZE/8);	//2bytes
		//System.out.println(Integer.SIZE/8);   //error
	}
}
