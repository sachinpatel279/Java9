#include<stdio.h>
void main(){
	printf("%ld\n",sizeof(int));      //4
	printf("%ld\n",sizeof(long));     //8
	printf("%ld\n",sizeof(char));     //1  
	printf("%ld\n",sizeof(float));    //4
	printf("%ld\n",sizeof(double));   //8
	printf("%ld\n",sizeof(_Bool));    //1




}
