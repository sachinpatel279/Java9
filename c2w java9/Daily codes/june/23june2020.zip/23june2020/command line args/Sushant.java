

class Sush{

	public static void main(String[] movies){

		System.out.println(movies.length);

	}

}
