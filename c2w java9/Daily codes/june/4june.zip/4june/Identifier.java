//class Narendra_Modi
//class $Narendra_Modi

class NarendraModi{
	
	int age=65;

	void work(){

	}

}

