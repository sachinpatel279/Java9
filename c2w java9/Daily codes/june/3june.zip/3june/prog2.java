import java.lang.*;

class Year2020{

	int x=10;

	Year2020(){
		System.out.println("in constructor");
	}

        public static void main(String[]args){

	    Year2020 obj=new Year2020();	
            System.out.println("Danger..!!");
            }
}

