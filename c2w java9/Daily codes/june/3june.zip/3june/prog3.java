

class Flat{
	
	int x=10;
	static int tv = 20;

	public static void main(String[]args){

		System.out.println("Static Demo");
	}

}
