

class AssignmentDemo{

	public static void main(String[]args){

		int age=26;

		System.out.println("Age="+age);
	}

}
