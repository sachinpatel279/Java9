

class ArithmeticDemo{

	public static void main(String[]args){

		int num1=20;
		int num2=10;
		int ans=0;

		ans=num1+num2;
		System.out.println("Add="+ans);
		
		ans=num1-num2;
		System.out.println("Sub="+ans);
		
		ans=num1*num2;
		System.out.println("Mul="+ans);
		
		ans=num1/num2;
		System.out.println("Div="+ans);
		
		ans=num1%num2;
		System.out.println("Mod="+ans);
	}

}
