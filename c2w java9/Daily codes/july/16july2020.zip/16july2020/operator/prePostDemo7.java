
class PrePostDemo7{

	public static void main(String[]args){

		int num=10;
		int ans=0;

		ans= ++num + ++num;
		System.out.println(ans);
		System.out.println(num);

	}

}
