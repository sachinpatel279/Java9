

#include<stdio.h>

void main(){

	int num1=10;
	int num2=20;
	_Bool ans;

	ans=num1 && num2;
	printf("%d\n",ans);//1
}
